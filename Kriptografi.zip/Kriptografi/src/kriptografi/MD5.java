/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kriptografi;

/**
 *
 * @author Mr. Dave
 */
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;
public class MD5 {
    static Scanner in;
    MessageDigest messageDigest;
    
    public MD5(){}

public String encrypt(String plaintext) throws NoSuchAlgorithmException{
messageDigest = MessageDigest.getInstance("MD5");
System.out.println("Metode Enkripsi : " + messageDigest.getAlgorithm());String input =  plaintext;
messageDigest.update(input.getBytes());
byte[] output = messageDigest.digest();
return convert(output);
}

private int byte2int(byte data) {
return data < 0 ? 256 + data : data;
}

public String convert(byte[] data) {
StringBuffer buffer = new StringBuffer();
for (byte b : data) {
String s = Integer.toHexString(byte2int(b));
if (s.length() < 2) {
buffer.append("0" + s);
} else {
buffer.append(s);
}
}
return buffer.toString();
}

public static void main(String[] args) throws NoSuchAlgorithmException {

in = new Scanner(System.in);
System.out.print("Masukkan Text = ");
String Text = in.next();
MD5 mde =new MD5();
System.out.println("MD5 (" + Text + ") = " + mde.encrypt(Text) );
}
}

